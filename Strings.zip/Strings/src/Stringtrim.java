public class Stringtrim {
    public static void main(String[] args) {
        String s1 = " Charan ";
        System.out.println(s1 + "loves coding");
        System.out.println(s1.trim() + "loves coding");
    }
}
