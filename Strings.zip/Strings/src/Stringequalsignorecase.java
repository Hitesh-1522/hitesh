public class Stringequalsignorecase {
    public static void main(String[] args) {
        String a="Charan";
        String b="CHARAN";
        String c="Srinivas";
        String d="SRINIVAS";
        System.out.println(a.equalsIgnoreCase(b));
        System.out.println(c.equalsIgnoreCase(d));
    }
}
