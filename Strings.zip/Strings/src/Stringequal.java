public class Stringequal {
    public static void main(String[] args) {
        //it will compare to strings wheather it is true or not
        String a="Charan";
        String b="CHARAN";
        String c="Srinivas";
        String d="Srinivas";
        System.out.println(a.equals(b));
        System.out.println(a.equals(c));
        System.out.println(c.equals(d));
    }
}
