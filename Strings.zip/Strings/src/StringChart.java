public class StringChart {
    public static void main(String[] args) {
        String a="Charan";
        char ch=a.charAt(0);
        System.out.println("The charcater present at 0 position is:"+ch);
    }
}
