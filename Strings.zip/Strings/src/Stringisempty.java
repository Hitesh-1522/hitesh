public class Stringisempty {
    public static void main(String[] args) {
        String s1="";
        String s2="This is Charan";

        System.out.println(s1.isEmpty());
        System.out.println(s2.isEmpty());
    }
}
