public class Stringjoin {
    public static void main(String[] args) {
        String joinString1=String.join(" ","Charan","Padma","Srikhar");
        System.out.println(joinString1);
    }
}
