public class Stringlength {
    public static void main(String[] args) {
        String s1="Charan";
        String s2="Srinivas";
        String s3="Sukrutha";
        System.out.println("string length is: "+s1.length());
        System.out.println("string length is: "+s2.length());
        System.out.println("String length is: "+s3.length());
    }
}
