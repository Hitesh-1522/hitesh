public class Stringtouppercase {
    public static void main(String[] args) {
        String s1="charan";
        String s1upper=s1.toUpperCase();
        System.out.println(s1upper);
    }
}
