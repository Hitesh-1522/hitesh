public class Stringreplace {
    public static void main(String[] args) {
        String s1="Charaj";
        String replaceString=s1.replace('j','n');//replaces all occurrences of 'a' to 'e'
        System.out.println(replaceString);
    }
}
