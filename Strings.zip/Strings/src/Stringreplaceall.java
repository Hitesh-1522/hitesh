public class Stringreplaceall {
    public static void main(String[] args) {
        String s1="This is Charan ";
        String replaceString=s1.replaceAll("s","w");
        System.out.println(replaceString);
    }
}
