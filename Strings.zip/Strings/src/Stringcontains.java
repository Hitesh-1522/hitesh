public class Stringcontains {
    public static void main(String[] args) {
        //it checks wheather the given condition is true or not
        //it gives boolean values only
        String a="Charan is a good boy";
        System.out.println(a.contains("good boy"));
        System.out.println(a.contains("Charan"));
        System.out.println(a.contains("Good"));
    }
}
