public class Stringendswith {
    public static void main(String[] args) {
        //it will check the last element of string wheather the last element is ending with that are not
        //it gives boolean type answer
        String a="Charan is doing coding";
        System.out.println(a.endsWith("g"));
        System.out.println(a.endsWith("coding"));
        System.out.println(a.endsWith("drinking"));
    }
}
