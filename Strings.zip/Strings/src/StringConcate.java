public class StringConcate {
    public static void main(String[] args) {
        String a="Charan";
        a.concat("is a good guy");
        System.out.println(a);
        a=a.concat(" is a good guy");
        System.out.println(a);


    }
}
