public class Stringlastindexof {
    public static void main(String[] args) {
        String s1="This is charan";
        int index1=s1.lastIndexOf('s');
        System.out.println(index1);
    }
}
