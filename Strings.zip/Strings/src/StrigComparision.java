public class StrigComparision {
    public static void main(String[] args) {
        String a="Charan";
       String b="Srinivas";
       String c="Sukrutha";
        System.out.println(a.compareTo(b));
        System.out.println(a.compareTo(c));
        System.out.println(b.compareTo(c));
    }
}
