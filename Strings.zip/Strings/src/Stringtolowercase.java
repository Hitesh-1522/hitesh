public class Stringtolowercase {
    public static void main(String[] args) {
        String s1="CHARAN";
        String s1lower=s1.toLowerCase();
        System.out.println(s1lower);
    }
}
