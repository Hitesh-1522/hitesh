public class Stringstartswith {
    public static void main(String[] args) {
        String s1="Charan loves coding";
        System.out.println(s1.startsWith("Ch"));
        System.out.println(s1.startsWith("Charan loves"));
        System.out.println(s1.startsWith("loves"));
    }
}
